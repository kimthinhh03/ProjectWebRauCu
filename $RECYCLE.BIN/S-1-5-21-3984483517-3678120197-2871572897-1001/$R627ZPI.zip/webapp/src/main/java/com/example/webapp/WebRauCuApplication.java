package com.example.webapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebRauCuApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebRauCuApplication.class, args);
	}

}
